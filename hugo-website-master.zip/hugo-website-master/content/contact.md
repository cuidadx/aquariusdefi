---
title: Contact
featured_image: "images/notebook.jpg"
omit_header_text: true
description: We'd love to hear from you
type: page
menu: main

---


This is an example of a custom shortcode that you can put right into your content. You will need to add a form action to the the shortcode to make it work. Check out [Formspree](https://formspree.io/) for a simple, free form service. 

{{< form-contact action="https://example.com"  >}}
